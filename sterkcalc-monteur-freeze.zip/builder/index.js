import { registerUnknownCommand } from "../utils/registerUnknownCommand.js"

function normalize(raw) {
  if (!raw || typeof raw !== "string") return null
  return raw.toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_|_$/g, "")
}

export async function runBuilder(payload = {}) {
  if (!payload || typeof payload !== "object") {
    throw new Error("BUILDER_INVALID_PAYLOAD")
  }

  const rawAction = payload.action || payload.actionId
  const action = normalize(rawAction)

  if (!action) throw new Error("BUILDER_ACTION_MISSING")

  try {
    switch (action) {
      case "write_files":
        return (await import("./monteur/write_files.js")).default(payload)
      case "create_module":
        return (await import("./monteur/create_module.js")).default(payload)
      case "create_folder":
        return (await import("./monteur/create_folder.js")).default(payload)
      case "delete_file":
        return (await import("./monteur/delete_file.js")).default(payload)
      case "delete_folder":
        return (await import("./monteur/delete_folder.js")).default(payload)
      case "repair_full_system":
        return (await import("./monteur/repair_full_system.js")).default(payload)
      case "system_repair_full_chain":
        return (await import("./monteur/system_repair_full_chain.js")).default(payload)
      case "freeze":
        return (await import("./monteur/freeze.js")).default(payload)
      case "unfreeze":
        return (await import("./monteur/unfreeze.js")).default(payload)
      default:
        await registerUnknownCommand("builder", action)
        return { action, state: "IGNORED" }
    }
  } catch (err) {
    throw new Error(`BUILDER_ACTION_FAILED (${action}): ${err.message}`)
  }
}